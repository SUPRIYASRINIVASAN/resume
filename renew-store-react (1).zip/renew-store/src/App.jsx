import React, { useState } from "react";
import "./App.css";

/* ---------------------------------------------------------
   ReNew — Refurbished Electronics Marketplace
   Design tokens:
   --moss:  #0F3D2E   primary dark (header, footer, ink blocks)
   --lime:  #C8F03C   signal accent (CTAs, grade ticks)
   --bone:  #F6F3EA   page background
   --ink:   #1B1F1C   text
   --clay:  #D98B5F   secondary warm accent
   Fonts: Space Grotesk (display), Inter (body), JetBrains Mono (specs/prices)
--------------------------------------------------------- */

const categories = [
  { name: "Smartphones", grade: "A+", icon: "📱", count: "12,400+" },
  { name: "Laptops", grade: "A", icon: "💻", count: "3,800+" },
  { name: "Smart Watches", grade: "A+", icon: "⌚", count: "1,950+" },
  { name: "Tablets", grade: "A", icon: "🔲", count: "2,100+" },
  { name: "Cameras", grade: "B+", icon: "📷", count: "640+" },
  { name: "Audio", grade: "A", icon: "🎧", count: "1,300+" },
];

const devices = [
  { name: "iPhone 13", spec: "128GB · Blue", grade: "A+", price: "₹32,499", mrp: "₹59,900" },
  { name: "Galaxy S22", spec: "256GB · Phantom Black", grade: "A", price: "₹28,999", mrp: "₹52,000" },
  { name: "MacBook Air M1", spec: "8GB/256GB · Space Grey", grade: "A+", price: "₹54,999", mrp: "₹92,990" },
  { name: "iPad 9th Gen", spec: "64GB · Wi-Fi", grade: "A", price: "₹18,499", mrp: "₹29,900" },
];

const steps = [
  { n: "01", title: "Tell us your device", body: "Pick the brand, model, and condition. Takes under a minute." },
  { n: "02", title: "Get an instant grade", body: "Our pricing engine checks live market data to quote fairly on the spot." },
  { n: "03", title: "Free doorstep pickup", body: "A technician inspects, confirms the grade, and pays you immediately." },
];

function GradeBadge({ grade }) {
  const colors = { "A+": "#C8F03C", A: "#9FE870", "B+": "#D98B5F" };
  return (
    <span className="grade-badge" style={{ "--grade-color": colors[grade] || "#C8F03C" }}>
      GRADE {grade}
    </span>
  );
}

function ScanStrip() {
  return (
    <div className="scan-strip" aria-hidden="true">
      {Array.from({ length: 28 }).map((_, i) => (
        <span key={i} className="scan-tick" style={{ animationDelay: `${i * 0.04}s` }} />
      ))}
    </div>
  );
}

function QuoteForm() {
  const [form, setForm] = useState({
    deviceType: "Smartphone",
    brand: "",
    model: "",
    condition: "Excellent",
    name: "",
    phone: "",
  });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const validate = () => {
    const err = {};
    if (!form.brand.trim()) err.brand = "Enter a brand.";
    if (!form.model.trim()) err.model = "Enter a model.";
    if (!form.name.trim()) err.name = "Enter your name.";
    if (!/^[6-9]\d{9}$/.test(form.phone.trim())) err.phone = "Enter a valid 10-digit mobile number.";
    return err;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const err = validate();
    setErrors(err);
    if (Object.keys(err).length === 0) {
      setSubmitted(true);
    }
  };

  const reset = () => {
    setForm({ deviceType: "Smartphone", brand: "", model: "", condition: "Excellent", name: "", phone: "" });
    setErrors({});
    setSubmitted(false);
  };

  if (submitted) {
    return (
      <div className="quote-success">
        <div className="success-mark">✓</div>
        <h3>Quote request received</h3>
        <p>
          We're pricing your <strong>{form.brand} {form.model}</strong> now. Expect a call on{" "}
          <strong>+91 {form.phone}</strong> within 15 minutes.
        </p>
        <button className="btn-ghost-lime" onClick={reset}>Request another quote</button>
      </div>
    );
  }

  return (
    <form className="quote-form" onSubmit={handleSubmit} noValidate>
      <div className="form-row">
        <label htmlFor="deviceType">Device type</label>
        <select id="deviceType" value={form.deviceType} onChange={update("deviceType")}>
          <option>Smartphone</option>
          <option>Laptop</option>
          <option>Smart Watch</option>
          <option>Tablet</option>
          <option>Camera</option>
        </select>
      </div>

      <div className="form-row form-row-split">
        <div>
          <label htmlFor="brand">Brand</label>
          <input
            id="brand"
            type="text"
            placeholder="e.g. Apple"
            value={form.brand}
            onChange={update("brand")}
            aria-invalid={!!errors.brand}
          />
          {errors.brand && <span className="field-error">{errors.brand}</span>}
        </div>
        <div>
          <label htmlFor="model">Model</label>
          <input
            id="model"
            type="text"
            placeholder="e.g. iPhone 13"
            value={form.model}
            onChange={update("model")}
            aria-invalid={!!errors.model}
          />
          {errors.model && <span className="field-error">{errors.model}</span>}
        </div>
      </div>

      <div className="form-row">
        <label htmlFor="condition">Condition</label>
        <div className="pill-group" role="radiogroup" aria-label="Condition">
          {["Excellent", "Good", "Fair", "Needs repair"].map((c) => (
            <button
              type="button"
              key={c}
              className={`pill ${form.condition === c ? "pill-active" : ""}`}
              onClick={() => setForm((f) => ({ ...f, condition: c }))}
              role="radio"
              aria-checked={form.condition === c}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div className="form-row form-row-split">
        <div>
          <label htmlFor="name">Your name</label>
          <input
            id="name"
            type="text"
            placeholder="Full name"
            value={form.name}
            onChange={update("name")}
            aria-invalid={!!errors.name}
          />
          {errors.name && <span className="field-error">{errors.name}</span>}
        </div>
        <div>
          <label htmlFor="phone">Mobile number</label>
          <div className="phone-input">
            <span>+91</span>
            <input
              id="phone"
              type="tel"
              placeholder="98765 43210"
              maxLength={10}
              value={form.phone}
              onChange={(e) => update("phone")({ target: { value: e.target.value.replace(/\D/g, "") } })}
              aria-invalid={!!errors.phone}
            />
          </div>
          {errors.phone && <span className="field-error">{errors.phone}</span>}
        </div>
      </div>

      <button type="submit" className="btn-solid-lime btn-full">Get my instant quote</button>
      <p className="form-footnote">No spam calls. We quote, you decide.</p>
    </form>
  );
}

export default function App() {
  const [navOpen, setNavOpen] = useState(false);

  return (
    <div className="page">
      {/* Header */}
      <header className="site-header">
        <div className="container header-inner">
          <div className="brand">
            <span className="brand-mark">Re</span>New
          </div>
          <nav className={`main-nav ${navOpen ? "open" : ""}`}>
            <a href="#categories">Buy Refurbished</a>
            <a href="#sell">Sell Your Device</a>
            <a href="#how">How It Works</a>
            <a href="#deals">Deals</a>
          </nav>
          <div className="header-actions">
            <button className="btn-outline-bone d-none-mobile">Track Order</button>
            <button className="btn-solid-lime">Login</button>
            <button className="nav-toggle" onClick={() => setNavOpen((v) => !v)} aria-label="Toggle menu">
              ☰
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="hero">
        <div className="container hero-inner">
          <div className="hero-copy">
            <p className="eyebrow">Every device, graded &amp; guaranteed</p>
            <h1>
              Good as new.
              <br />
              Priced like it isn't.
            </h1>
            <p className="hero-sub">
              We test, grade, and certify every refurbished phone, laptop, and watch we sell —
              so the only surprise is how much you saved.
            </p>
            <div className="hero-ctas">
              <a href="#categories" className="btn-solid-lime">Shop refurbished</a>
              <a href="#sell" className="btn-outline-bone">Sell your phone</a>
            </div>
            <div className="hero-stats">
              <div><strong>4.6/5</strong><span>Customer rating</span></div>
              <div><strong>18 mo</strong><span>Warranty on every device</span></div>
              <div><strong>2.1M+</strong><span>Devices renewed</span></div>
            </div>
          </div>
          <div className="hero-grade-card">
            <ScanStrip />
            <div className="grade-card-body">
              <span className="grade-card-label">Quality report</span>
              <h3>iPhone 13 · 128GB</h3>
              <GradeBadge grade="A+" />
              <ul className="grade-checklist">
                <li>Battery health 92%+</li>
                <li>Screen — no scratches</li>
                <li>Body — minimal wear</li>
                <li>38-point function test passed</li>
              </ul>
              <div className="grade-price">
                <span className="price-now">₹32,499</span>
                <span className="price-was">₹59,900</span>
              </div>
            </div>
            <ScanStrip />
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="section" id="categories">
        <div className="container">
          <div className="section-head">
            <p className="eyebrow">Browse by category</p>
            <h2>Find your next device</h2>
          </div>
          <div className="category-grid">
            {categories.map((c) => (
              <div className="category-card" key={c.name}>
                <div className="category-icon">{c.icon}</div>
                <h4>{c.name}</h4>
                <p className="category-count">{c.count} in stock</p>
                <GradeBadge grade={c.grade} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Deals */}
      <section className="section section-tint" id="deals">
        <div className="container">
          <div className="section-head">
            <p className="eyebrow">Today's picks</p>
            <h2>Top-graded, ready to ship</h2>
          </div>
          <div className="device-grid">
            {devices.map((d) => (
              <div className="device-card" key={d.name}>
                <div className="device-thumb" aria-hidden="true" />
                <GradeBadge grade={d.grade} />
                <h4>{d.name}</h4>
                <p className="device-spec">{d.spec}</p>
                <div className="device-price">
                  <span className="price-now">{d.price}</span>
                  <span className="price-was">{d.mrp}</span>
                </div>
                <button className="btn-outline-moss btn-full">Add to cart</button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="section" id="how">
        <div className="container">
          <div className="section-head">
            <p className="eyebrow">Selling is simple</p>
            <h2>How trading in works</h2>
          </div>
          <div className="steps-row">
            {steps.map((s) => (
              <div className="step-card" key={s.n}>
                <span className="step-num">{s.n}</span>
                <h4>{s.title}</h4>
                <p>{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sell / Quote form */}
      <section className="section section-dark" id="sell">
        <div className="container sell-inner">
          <div className="sell-copy">
            <p className="eyebrow eyebrow-lime">Sell your device</p>
            <h2>Get a fair price in under 60 seconds</h2>
            <p className="sell-sub">
              Tell us about your phone, laptop, or watch. We'll quote a price backed by real
              resale data — and pick it up from your doorstep for free.
            </p>
            <ul className="sell-points">
              <li>Instant, no-obligation quote</li>
              <li>Free pickup, anywhere in India</li>
              <li>Get paid the moment it's verified</li>
            </ul>
          </div>
          <div className="sell-form-wrap">
            <QuoteForm />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="site-footer">
        <div className="container footer-inner">
          <div className="brand brand-footer">
            <span className="brand-mark">Re</span>New
          </div>
          <p>© 2026 ReNew Devices Pvt. Ltd. Every device tested. Every price honest.</p>
        </div>
      </footer>
    </div>
  );
}
