# ReNew — Refurbished Electronics Storefront

A React + Bootstrap homepage for a refurbished-devices marketplace (phones, laptops, watches),
inspired by sites like Cashify, with its own visual identity: a deep moss-green and
signal-lime palette, Space Grotesk/JetBrains Mono typography, and a "quality grade card"
as the signature visual element.

## What's included

- `src/App.jsx` — the full page: header, hero with a live-looking grade card, category
  grid, deal cards, "how it works" steps, and a working **Sell Your Device** quote form.
- `src/App.css` — all styling (no Bootstrap component classes were relied on for visual
  design — Bootstrap is loaded via CDN in `public/index.html` for grid/utility classes
  if you want to extend the page, but the layout here uses CSS Grid/Flexbox directly).
- `src/index.js` — React entry point.
- `public/index.html` — HTML shell, loads Bootstrap from a CDN.

## Running it

```bash
npm install
npm start
```

Opens at `http://localhost:3000`.

To build for production:

```bash
npm run build
```

## The form (Sell Your Device)

`QuoteForm` inside `App.jsx` is a real, validated React form:

- **Fields**: device type (select), brand, model, condition (pill buttons), name, and a
  10-digit Indian mobile number (auto-prefixed with `+91`, strips non-digits as you type).
- **Validation**: brand, model, and name must be non-empty; phone must match a valid
  10-digit Indian mobile pattern (`^[6-9]\d{9}$`). Errors show inline under each field.
- **Submit**: on success, swaps to a confirmation card showing the device and number,
  with a button to reset and submit another quote.

This is front-end only — there's no backend call. To wire it to a real API, replace the
body of `handleSubmit` in `QuoteForm` with your `fetch`/`axios` call.

## Customizing

- Colors live as CSS variables at the top of `App.css` (`--moss`, `--lime`, `--bone`,
  `--ink`, `--clay`) — change these to retheme the whole page.
- Category and device data are plain arrays (`categories`, `devices`) near the top of
  `App.jsx` — edit those to swap in real inventory.
